"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "BitergiaAnalyticsPluginSetup", {
  enumerable: true,
  get: function () {
    return _types.BitergiaAnalyticsPluginSetup;
  }
});
Object.defineProperty(exports, "BitergiaAnalyticsPluginStart", {
  enumerable: true,
  get: function () {
    return _types.BitergiaAnalyticsPluginStart;
  }
});
exports.config = void 0;
exports.plugin = plugin;

var _configSchema = require("@osd/config-schema");

var _plugin = require("./plugin");

var _types = require("./types");

/*
 * Copyright 2021-2022 Bitergia
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
// This exports static code and TypeScript types,
// as well as, OpenSearch Dashboards Platform `plugin()` initializer.
const config = {
  exposeToBrowser: {
    branding: true,
    hideTenantSelector: true
  },
  schema: _configSchema.schema.object({
    branding: _configSchema.schema.object({
      backgroundColor: _configSchema.schema.string({
        defaultValue: '#333'
      }),
      textColor: _configSchema.schema.string({
        defaultValue: '#cecece'
      }),
      menuItemColor: _configSchema.schema.string({
        defaultValue: '#dedede'
      }),
      menuItemHoverColor: _configSchema.schema.string({
        defaultValue: '#000000'
      }),
      linkColor: _configSchema.schema.string({
        defaultValue: '#fcb42e'
      }),
      selectedItemColor: _configSchema.schema.string({
        defaultValue: '#f49e42'
      }),
      dropdownColor: _configSchema.schema.string({
        defaultValue: '#525252'
      }),
      projectName: _configSchema.schema.string({
        defaultValue: 'Bitergia Analytics'
      })
    }),
    hideTenantSelector: _configSchema.schema.boolean({
      defaultValue: true
    })
  })
};
exports.config = config;

function plugin(initializerContext) {
  return new _plugin.BitergiaAnalyticsPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImNvbmZpZyIsImV4cG9zZVRvQnJvd3NlciIsImJyYW5kaW5nIiwiaGlkZVRlbmFudFNlbGVjdG9yIiwic2NoZW1hIiwib2JqZWN0IiwiYmFja2dyb3VuZENvbG9yIiwic3RyaW5nIiwiZGVmYXVsdFZhbHVlIiwidGV4dENvbG9yIiwibWVudUl0ZW1Db2xvciIsIm1lbnVJdGVtSG92ZXJDb2xvciIsImxpbmtDb2xvciIsInNlbGVjdGVkSXRlbUNvbG9yIiwiZHJvcGRvd25Db2xvciIsInByb2plY3ROYW1lIiwiYm9vbGVhbiIsInBsdWdpbiIsImluaXRpYWxpemVyQ29udGV4dCIsIkJpdGVyZ2lhQW5hbHl0aWNzUGx1Z2luIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWdCQTs7QUFFQTs7QUE2QkE7O0FBL0NBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU1BO0FBQ0E7QUFFTyxNQUFNQSxNQUFNLEdBQUc7QUFDcEJDLEVBQUFBLGVBQWUsRUFBRTtBQUNmQyxJQUFBQSxRQUFRLEVBQUUsSUFESztBQUVmQyxJQUFBQSxrQkFBa0IsRUFBRTtBQUZMLEdBREc7QUFLcEJDLEVBQUFBLE1BQU0sRUFBRUEscUJBQU9DLE1BQVAsQ0FBYztBQUNwQkgsSUFBQUEsUUFBUSxFQUFFRSxxQkFBT0MsTUFBUCxDQUFjO0FBQ3RCQyxNQUFBQSxlQUFlLEVBQUVGLHFCQUFPRyxNQUFQLENBQWM7QUFBRUMsUUFBQUEsWUFBWSxFQUFFO0FBQWhCLE9BQWQsQ0FESztBQUV0QkMsTUFBQUEsU0FBUyxFQUFFTCxxQkFBT0csTUFBUCxDQUFjO0FBQUVDLFFBQUFBLFlBQVksRUFBRTtBQUFoQixPQUFkLENBRlc7QUFHdEJFLE1BQUFBLGFBQWEsRUFBRU4scUJBQU9HLE1BQVAsQ0FBYztBQUFFQyxRQUFBQSxZQUFZLEVBQUU7QUFBaEIsT0FBZCxDQUhPO0FBSXRCRyxNQUFBQSxrQkFBa0IsRUFBRVAscUJBQU9HLE1BQVAsQ0FBYztBQUFFQyxRQUFBQSxZQUFZLEVBQUU7QUFBaEIsT0FBZCxDQUpFO0FBS3RCSSxNQUFBQSxTQUFTLEVBQUVSLHFCQUFPRyxNQUFQLENBQWM7QUFBRUMsUUFBQUEsWUFBWSxFQUFFO0FBQWhCLE9BQWQsQ0FMVztBQU10QkssTUFBQUEsaUJBQWlCLEVBQUVULHFCQUFPRyxNQUFQLENBQWM7QUFBRUMsUUFBQUEsWUFBWSxFQUFFO0FBQWhCLE9BQWQsQ0FORztBQU90Qk0sTUFBQUEsYUFBYSxFQUFFVixxQkFBT0csTUFBUCxDQUFjO0FBQUVDLFFBQUFBLFlBQVksRUFBRTtBQUFoQixPQUFkLENBUE87QUFRdEJPLE1BQUFBLFdBQVcsRUFBRVgscUJBQU9HLE1BQVAsQ0FBYztBQUFFQyxRQUFBQSxZQUFZLEVBQUU7QUFBaEIsT0FBZDtBQVJTLEtBQWQsQ0FEVTtBQVdwQkwsSUFBQUEsa0JBQWtCLEVBQUVDLHFCQUFPWSxPQUFQLENBQWU7QUFBRVIsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWY7QUFYQSxHQUFkO0FBTFksQ0FBZjs7O0FBb0JBLFNBQVNTLE1BQVQsQ0FBZ0JDLGtCQUFoQixFQUE4RDtBQUNuRSxTQUFPLElBQUlDLCtCQUFKLENBQTRCRCxrQkFBNUIsQ0FBUDtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCAyMDIxLTIwMjIgQml0ZXJnaWFcbiAqIENvcHlyaWdodCAyMDIwIEFtYXpvbi5jb20sIEluYy4gb3IgaXRzIGFmZmlsaWF0ZXMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKS5cbiAqIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIEEgY29weSBvZiB0aGUgTGljZW5zZSBpcyBsb2NhdGVkIGF0XG4gKlxuICogaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogb3IgaW4gdGhlIFwibGljZW5zZVwiIGZpbGUgYWNjb21wYW55aW5nIHRoaXMgZmlsZS4gVGhpcyBmaWxlIGlzIGRpc3RyaWJ1dGVkXG4gKiBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcbiAqIGV4cHJlc3Mgb3IgaW1wbGllZC4gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nXG4gKiBwZXJtaXNzaW9ucyBhbmQgbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgc2NoZW1hIH0gZnJvbSAnQG9zZC9jb25maWctc2NoZW1hJztcbmltcG9ydCB7IFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCB9IGZyb20gJy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBCaXRlcmdpYUFuYWx5dGljc1BsdWdpbiB9IGZyb20gJy4vcGx1Z2luJztcblxuLy8gVGhpcyBleHBvcnRzIHN0YXRpYyBjb2RlIGFuZCBUeXBlU2NyaXB0IHR5cGVzLFxuLy8gYXMgd2VsbCBhcywgT3BlblNlYXJjaCBEYXNoYm9hcmRzIFBsYXRmb3JtIGBwbHVnaW4oKWAgaW5pdGlhbGl6ZXIuXG5cbmV4cG9ydCBjb25zdCBjb25maWcgPSB7XG4gIGV4cG9zZVRvQnJvd3Nlcjoge1xuICAgIGJyYW5kaW5nOiB0cnVlLFxuICAgIGhpZGVUZW5hbnRTZWxlY3RvcjogdHJ1ZSxcbiAgfSxcbiAgc2NoZW1hOiBzY2hlbWEub2JqZWN0KHtcbiAgICBicmFuZGluZzogc2NoZW1hLm9iamVjdCh7XG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcjMzMzJyB9KSxcbiAgICAgIHRleHRDb2xvcjogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJyNjZWNlY2UnIH0pLFxuICAgICAgbWVudUl0ZW1Db2xvcjogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJyNkZWRlZGUnIH0pLFxuICAgICAgbWVudUl0ZW1Ib3ZlckNvbG9yOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnIzAwMDAwMCcgfSksXG4gICAgICBsaW5rQ29sb3I6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcjZmNiNDJlJyB9KSxcbiAgICAgIHNlbGVjdGVkSXRlbUNvbG9yOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnI2Y0OWU0MicgfSksXG4gICAgICBkcm9wZG93bkNvbG9yOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnIzUyNTI1MicgfSksXG4gICAgICBwcm9qZWN0TmFtZTogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJ0JpdGVyZ2lhIEFuYWx5dGljcycgfSksXG4gICAgfSksXG4gICAgaGlkZVRlbmFudFNlbGVjdG9yOiBzY2hlbWEuYm9vbGVhbih7IGRlZmF1bHRWYWx1ZTogdHJ1ZSB9KSxcbiAgfSksXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gcGx1Z2luKGluaXRpYWxpemVyQ29udGV4dDogUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0KSB7XG4gIHJldHVybiBuZXcgQml0ZXJnaWFBbmFseXRpY3NQbHVnaW4oaW5pdGlhbGl6ZXJDb250ZXh0KTtcbn1cblxuZXhwb3J0IHtcbiAgQml0ZXJnaWFBbmFseXRpY3NQbHVnaW5TZXR1cCxcbiAgQml0ZXJnaWFBbmFseXRpY3NQbHVnaW5TdGFydCxcbn0gZnJvbSAnLi90eXBlcyc7XG4iXX0=