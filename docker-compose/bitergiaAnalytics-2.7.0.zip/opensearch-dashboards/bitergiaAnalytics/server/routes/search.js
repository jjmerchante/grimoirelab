"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerSearchRoutes = void 0;

var _configSchema = require("@osd/config-schema");

var _common = require("../../common");

/*
 * Copyright 2021-2022 Bitergia
 * Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
const registerSearchRoutes = function (router) {
  router.put({
    path: `${_common.API_PREFIX}/search/dashboards`,
    validate: {
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    try {
      var _result$body;

      const requestClient = context.core.opensearch.client.asCurrentUser;
      const result = await requestClient.search({
        index: '.kibana',
        size: 100,
        body: {
          _source: ['dashboard.title'],
          query: {
            bool: {
              must: [{
                term: {
                  type: 'dashboard'
                }
              }]
            }
          }
        }
      });
      return response.ok({
        body: (_result$body = result.body) === null || _result$body === void 0 ? void 0 : _result$body.hits
      });
    } catch (error) {
      return response.customError({
        body: error,
        statusCode: error.statusCode
      });
    }
  });
};

exports.registerSearchRoutes = registerSearchRoutes;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaC50cyJdLCJuYW1lcyI6WyJyZWdpc3RlclNlYXJjaFJvdXRlcyIsInJvdXRlciIsInB1dCIsInBhdGgiLCJBUElfUFJFRklYIiwidmFsaWRhdGUiLCJib2R5Iiwic2NoZW1hIiwiYW55IiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsInJlcXVlc3RDbGllbnQiLCJjb3JlIiwib3BlbnNlYXJjaCIsImNsaWVudCIsImFzQ3VycmVudFVzZXIiLCJyZXN1bHQiLCJzZWFyY2giLCJpbmRleCIsInNpemUiLCJfc291cmNlIiwicXVlcnkiLCJib29sIiwibXVzdCIsInRlcm0iLCJ0eXBlIiwib2siLCJoaXRzIiwiZXJyb3IiLCJjdXN0b21FcnJvciIsInN0YXR1c0NvZGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFnQkE7O0FBTUE7O0FBdEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVVPLE1BQU1BLG9CQUFvQixHQUFHLFVBQVVDLE1BQVYsRUFBMkI7QUFDN0RBLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxvQkFEdEI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFO0FBQ1JDLE1BQUFBLElBQUksRUFBRUMscUJBQU9DLEdBQVA7QUFERTtBQUZaLEdBREYsRUFPRSxPQUNFQyxPQURGLEVBRUVDLE9BRkYsRUFHRUMsUUFIRixLQUlrRTtBQUNoRSxRQUFJO0FBQUE7O0FBQ0YsWUFBTUMsYUFBYSxHQUFHSCxPQUFPLENBQUNJLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0JDLGFBQXJEO0FBQ0EsWUFBTUMsTUFBTSxHQUFHLE1BQU1MLGFBQWEsQ0FBQ00sTUFBZCxDQUFxQjtBQUN4Q0MsUUFBQUEsS0FBSyxFQUFFLFNBRGlDO0FBRXhDQyxRQUFBQSxJQUFJLEVBQUUsR0FGa0M7QUFHeENkLFFBQUFBLElBQUksRUFBRTtBQUNKZSxVQUFBQSxPQUFPLEVBQUUsQ0FBQyxpQkFBRCxDQURMO0FBRUpDLFVBQUFBLEtBQUssRUFBRTtBQUNMQyxZQUFBQSxJQUFJLEVBQUU7QUFDSkMsY0FBQUEsSUFBSSxFQUFFLENBQ0o7QUFDRUMsZ0JBQUFBLElBQUksRUFBRTtBQUNKQyxrQkFBQUEsSUFBSSxFQUFFO0FBREY7QUFEUixlQURJO0FBREY7QUFERDtBQUZIO0FBSGtDLE9BQXJCLENBQXJCO0FBbUJBLGFBQU9mLFFBQVEsQ0FBQ2dCLEVBQVQsQ0FBWTtBQUNqQnJCLFFBQUFBLElBQUksa0JBQUVXLE1BQU0sQ0FBQ1gsSUFBVCxpREFBRSxhQUFhc0I7QUFERixPQUFaLENBQVA7QUFHRCxLQXhCRCxDQXdCRSxPQUFPQyxLQUFQLEVBQWM7QUFDZCxhQUFPbEIsUUFBUSxDQUFDbUIsV0FBVCxDQUFxQjtBQUMxQnhCLFFBQUFBLElBQUksRUFBRXVCLEtBRG9CO0FBRTFCRSxRQUFBQSxVQUFVLEVBQUVGLEtBQUssQ0FBQ0U7QUFGUSxPQUFyQixDQUFQO0FBSUQ7QUFDRixHQTFDSDtBQTRDRCxDQTdDTSIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBDb3B5cmlnaHQgMjAyMS0yMDIyIEJpdGVyZ2lhXG4gKiBDb3B5cmlnaHQgMjAyMCBBbWF6b24uY29tLCBJbmMuIG9yIGl0cyBhZmZpbGlhdGVzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXG4gKiBZb3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxuICpcbiAqIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxuICogb24gYW4gXCJBUyBJU1wiIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyXG4gKiBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xuICogcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0Bvc2QvY29uZmlnLXNjaGVtYSc7XG5pbXBvcnQge1xuICBJUm91dGVyLFxuICBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlLFxuICBSZXNwb25zZUVycm9yLFxufSBmcm9tICcuLi8uLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgQVBJX1BSRUZJWCB9IGZyb20gJy4uLy4uL2NvbW1vbic7XG5cbmV4cG9ydCBjb25zdCByZWdpc3RlclNlYXJjaFJvdXRlcyA9IGZ1bmN0aW9uIChyb3V0ZXI6IElSb3V0ZXIpIHtcbiAgcm91dGVyLnB1dChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS9zZWFyY2gvZGFzaGJvYXJkc2AsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEuYW55KCksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKFxuICAgICAgY29udGV4dCxcbiAgICAgIHJlcXVlc3QsXG4gICAgICByZXNwb25zZVxuICAgICk6IFByb21pc2U8SU9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2U8YW55IHwgUmVzcG9uc2VFcnJvcj4+ID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcXVlc3RDbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVxdWVzdENsaWVudC5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiAnLmtpYmFuYScsXG4gICAgICAgICAgc2l6ZTogMTAwLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIF9zb3VyY2U6IFsnZGFzaGJvYXJkLnRpdGxlJ10sXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgICAgbXVzdDogW1xuICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICB0ZXJtOiB7XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2Rhc2hib2FyZCcsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogcmVzdWx0LmJvZHk/LmhpdHMsXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBib2R5OiBlcnJvcixcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnJvci5zdGF0dXNDb2RlLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG59O1xuIl19